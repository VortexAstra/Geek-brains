import UIKit

struct Group {
    var name: String
    var description: String
    var image: UIImage
    
}
