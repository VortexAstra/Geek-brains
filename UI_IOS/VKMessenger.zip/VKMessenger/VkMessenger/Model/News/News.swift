import UIKit

struct News {
    var name: String
    var description: String
}
