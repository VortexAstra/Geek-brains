import UIKit

struct Friend {
    var id: Int
    var name: String
    var photo: [UIImage]
}
