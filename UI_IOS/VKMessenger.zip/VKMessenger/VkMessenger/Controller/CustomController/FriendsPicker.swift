import UIKit

class FriendPicker: UIControl {
    
    
}
