import UIKit

class AllGroupTableViewCell: UITableViewCell {    
    @IBOutlet weak var groupImage: UIImageView!
    @IBOutlet weak var groupName: UILabel!
}
