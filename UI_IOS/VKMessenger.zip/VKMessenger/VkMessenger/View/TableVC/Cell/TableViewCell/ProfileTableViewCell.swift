import UIKit

class ProfileTableViewCell: UITableViewCell {

}
